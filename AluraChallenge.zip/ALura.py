"""
análisis_tiendas.py
Script completo para:
 - Cargar 4 tiendas (CSV desde raw GitHub)
 - Limpiar y unificar datos
 - Calcular métricas: ingresos, categorías top, reseñas, productos top, envío promedio
 - Generar >=3 gráficos distintos (barras, pie, scatter, heatmap)
 - Calcular un 'score de eficiencia' y recomendar cuál tienda vender
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path


# 1) CONFIGURACIÓN: URLs raw

urls = {
    "tienda_1": "https://raw.githubusercontent.com/alura-es-cursos/challenge1-data-science-latam/c280e292765416420f1bffa6f324a07ef021e1b0/base-de-datos-challenge1-latam/tienda_1%20.csv",
    "tienda_2": "https://raw.githubusercontent.com/alura-es-cursos/challenge1-data-science-latam/c280e292765416420f1bffa6f324a07ef021e1b0/base-de-datos-challenge1-latam/tienda_2.csv",
    "tienda_3": "https://raw.githubusercontent.com/alura-es-cursos/challenge1-data-science-latam/c280e292765416420f1bffa6f324a07ef021e1b0/base-de-datos-challenge1-latam/tienda_3.csv",
    "tienda_4": "https://raw.githubusercontent.com/alura-es-cursos/challenge1-data-science-latam/c280e292765416420f1bffa6f324a07ef021e1b0/base-de-datos-challenge1-latam/tienda_4.csv",
}

# Carpeta de salida para figuras/resultados
out_dir = Path("analisis_tiendas_output")
out_dir.mkdir(exist_ok=True)

# 2) CARGA DE DATOS

dfs = {}
for name, url in urls.items():
    try:
        print(f"Cargando {name} desde {url} ...")
        df = pd.read_csv(url)
        dfs[name] = df
    except Exception as e:
        print(f"Error cargando {name}: {e}")
        # Si falla la descarga, el usuario puede subir localmente/ajustar la URL.
        dfs[name] = None

# Verificación rápida
for k, df in dfs.items():
    if df is None:
        print(f">>>> {k} no se pudo cargar. Asegúrate de la URL o sube el CSV localmente.")
    else:
        print(f"{k}: shape={df.shape}, columnas={list(df.columns)[:10]}")


# 3) FUNCIÓN DE LIMPIEZA Y NORMALIZACIÓN

def clean_store_df(df):
    """
    Normaliza nombres de columnas, convierte tipos y crea columnas útiles:
    - price (float), quantity (int), shipping_cost (float)
    - revenue = price * quantity
    - category normalized (lower + strip)
    - rating as numeric (if existe)
    - order_id & product_name guardados si están
    """
    df = df.copy()
    # Normalizar nombres
    df.columns = df.columns.str.strip().str.lower().str.replace(" ", "_")

    # Intentos de detección de columnas comunes
    # price
    for candidate in ["price", "preco", "valor", "valor_unitario"]:
        if candidate in df.columns:
            price_col = candidate
            break
    else:
        # si no existe, buscar por palabras clave
        price_candidates = [c for c in df.columns if "price" in c or "preco" in c or "valor" in c]
        price_col = price_candidates[0] if price_candidates else None


    if price_col:
        # quitar símbolos y convertir
        df[price_col] = df[price_col].astype(str).str.replace(r"[^\d\.\-\,]", "", regex=True)
        # reemplazar comas por puntos si necesario (ej: "1,234.56" vs "1.234,56")
        df[price_col] = df[price_col].str.replace(",", ".")
        df["price"] = pd.to_numeric(df[price_col], errors="coerce")
    else:
        df["price"] = np.nan

    # quantity
    qty_col = None
    for candidate in ["quantity", "quantidade", "qty"]:
        if candidate in df.columns:
            qty_col = candidate
            break
    if qty_col:
        df["quantity"] = pd.to_numeric(df[qty_col], errors="coerce").fillna(1).astype(int)
    else:
        # si no hay quantity, asumimos 1 por fila
        df["quantity"] = 1

    # shipping_cost
    ship_col = None
    for candidate in ["shipping_cost", "frete", "shipping"]:
        if candidate in df.columns:
            ship_col = candidate
            break
    if ship_col:
        df[ship_col] = df[ship_col].astype(str).str.replace(r"[^\d\.\-\,]", "", regex=True).str.replace(",", ".")
        df["shipping_cost"] = pd.to_numeric(df[ship_col], errors="coerce")
    else:
        df["shipping_cost"] = np.nan

    # rating
    rating_col = None
    for candidate in ["rating", "avaliacao", "review_score", "score"]:
        if candidate in df.columns:
            rating_col = candidate
            break
    if rating_col:
        df["rating"] = pd.to_numeric(df[rating_col], errors="coerce")
    else:
        df["rating"] = np.nan

    # category
    cat_col = None
    for candidate in ["category", "categoria", "cat"]:
        if candidate in df.columns:
            cat_col = candidate
            break
    if cat_col:
        df["category"] = df[cat_col].astype(str).str.lower().str.strip()
    else:
        df["category"] = "sin_categoria"

    # product name/id
    prod_col = None
    for candidate in ["product_name", "produto", "name", "product"]:
        if candidate in df.columns:
            prod_col = candidate
            break
    if prod_col:
        df["product_name"] = df[prod_col].astype(str).str.strip()
    else:
        df["product_name"] = "sin_nombre"

    # order id (opcional)
    if "order_id" in df.columns:
        df["order_id"] = df["order_id"]
    else:
        # si no existe, crear un id por fila (no ideal, pero sirve para conteos)
        df["order_id"] = np.arange(len(df)).astype(str)

    # revenue
    df["revenue"] = df["price"] * df["quantity"]

    # algunas estadísticas rapidas
    return df

# Aplicar limpieza a cada DF cargado
for k, df in list(dfs.items()):
    if df is not None:
        dfs[k] = clean_store_df(df)


# 4) CÁLCULOS PRINCIPALES POR TIENDA
summary_rows = []
combined = []
for store_name, df in dfs.items():
    if df is None:
        continue
    total_revenue = df["revenue"].sum(skipna=True)
    n_orders = df["order_id"].nunique()
    avg_order_value = total_revenue / n_orders if n_orders > 0 else 0
    avg_shipping = df["shipping_cost"].mean(skipna=True)
    avg_rating = df["rating"].mean(skipna=True)
    n_reviews = df["rating"].count()
    total_qty = df["quantity"].sum()
    summary_rows.append({
        "store": store_name,
        "total_revenue": float(total_revenue),
        "n_orders": int(n_orders),
        "total_qty": int(total_qty),
        "avg_order_value": float(avg_order_value),
        "avg_shipping": float(avg_shipping) if not np.isnan(avg_shipping) else np.nan,
        "avg_rating": float(avg_rating) if not np.isnan(avg_rating) else np.nan,
        "n_reviews": int(n_reviews)
    })
    # añadir etiqueta de tienda en el df combinado
    temp = df.copy()
    temp["store"] = store_name
    combined.append(temp)

summary_df = pd.DataFrame(summary_rows).set_index("store").sort_values("total_revenue", ascending=False)
combined_df = pd.concat(combined, ignore_index=True) if combined else pd.DataFrame()

# Guardar resumen
summary_df.to_csv(out_dir / "resumen_tiendas.csv")
print("\nResumen por tienda guardado en:", out_dir / "resumen_tiendas.csv")
print(summary_df)


# 5) ANÁLISIS ADICIONAL: categorías y productos top


# Top categorías por tienda
top_cats = {}
top_products = {}
for store in combined_df["store"].unique():
    df = combined_df[combined_df["store"] == store]
    cat_sales = df.groupby("category").agg(total_revenue=("revenue", "sum"),
                                          total_qty=("quantity", "sum")).sort_values("total_revenue", ascending=False)
    top_cats[store] = cat_sales.head(6)
    prod_sales = df.groupby("product_name").agg(total_revenue=("revenue", "sum"),
                                                total_qty=("quantity", "sum")).sort_values("total_qty", ascending=False)
    top_products[store] = prod_sales.head(10)

# Guardar ejemplos
for store, catdf in top_cats.items():
    catdf.to_csv(out_dir / f"top_categories_{store}.csv")
for store, proddf in top_products.items():
    proddf.to_csv(out_dir / f"top_products_{store}.csv")

print("\nTop categorías y productos guardados en", out_dir)


# 6) GRAFICOS (>=3 diferentes)
#   - Gráfico A: barras de ingresos totales por tienda
#   - Gráfico B: pie (donut) de distribución por categoría para cada tienda (ej. la 1)
#   - Gráfico C: scatter precio vs rating (tamaño = qty)
#   - Gráfico D: heatmap (matriz) revenue por categoría x tienda

plt.rcParams.update({"figure.max_open_warning": 0})

# A: Barras - ingresos por tienda
plt.figure(figsize=(8,5))
stores = summary_df.index.tolist()
revenues = summary_df["total_revenue"].values
plt.bar(stores, revenues)
plt.title("Ingresos Totales por Tienda")
plt.ylabel("Ingresos (moneda)")
plt.xlabel("Tienda")
plt.xticks(rotation=10)
for i, v in enumerate(revenues):
    plt.text(i, v * 1.01, f"{v:,.0f}", ha="center", va="bottom", fontsize=9)
plt.tight_layout()
plt.savefig(out_dir / "ingresos_por_tienda_bar.png", dpi=150)
plt.close()

# B: Pie/donut - categoría top para cada tienda (si hay datos)
for store in combined_df["store"].unique():
    df = combined_df[combined_df["store"] == store]
    cat = df.groupby("category")["revenue"].sum().sort_values(ascending=False)
    if cat.sum() == 0:
        continue
    top = cat.head(6)
    others = cat.iloc[6:].sum()
    if others > 0:
        top["otros"] = others
    plt.figure(figsize=(6,6))
    patches, texts, autotexts = plt.pie(top.values, labels=top.index, autopct="%1.1f%%", startangle=90)
    plt.title(f"Distribución de Ingresos por Categoría - {store}")
    # Donut: dibujar círculo blanco en el centro
    centre_circle = plt.Circle((0,0), 0.50, fc="white")
    fig = plt.gcf()
    fig.gca().add_artist(centre_circle)
    plt.tight_layout()
    plt.savefig(out_dir / f"cat_pie_{store}.png", dpi=150)
    plt.close()

# C: Scatter - precio vs rating (tamaño = cantidad vendida)
# Usar solo filas con price y rating válidos
sc_df = combined_df.dropna(subset=["price", "rating"])
if not sc_df.empty:
    plt.figure(figsize=(8,6))
    sizes = (sc_df["quantity"].clip(upper=100) / sc_df["quantity"].max()) * 200  # tamaño relativo
    plt.scatter(sc_df["price"], sc_df["rating"], s=sizes, alpha=0.6)
    plt.xlabel("Precio")
    plt.ylabel("Rating")
    plt.title("Precio vs Rating (tamaño ~ cantidad vendida)")
    plt.grid(True, linestyle="--", linewidth=0.3)
    plt.tight_layout()
    plt.savefig(out_dir / "precio_vs_rating_scatter.png", dpi=150)
    plt.close()

# D: Heatmap/matriz de revenue por categoría x tienda
pivot = combined_df.pivot_table(index="category", columns="store", values="revenue", aggfunc="sum").fillna(0)
if not pivot.empty:
    plt.figure(figsize=(10, max(4, pivot.shape[0]*0.4)))
    # normalizar por filas para visualizar share dentro de cada categoría (opcional)
    mat = pivot.values
    # imshow heatmap
    im = plt.imshow(mat, aspect="auto")
    plt.colorbar(im, orientation="vertical")
    plt.yticks(range(len(pivot.index)), pivot.index)
    plt.xticks(range(len(pivot.columns)), pivot.columns, rotation=45)
    plt.title("Heatmap: Revenue por Categoría (filas) y Tienda (columnas)")
    # Anotar valores (si la matriz no es muy grande)
    if mat.size <= 200:
        for i in range(mat.shape[0]):
            for j in range(mat.shape[1]):
                plt.text(j, i, f"{mat[i,j]:,.0f}", ha="center", va="center", fontsize=8, color="white" if mat[i,j] > mat.max()*0.5 else "black")
    plt.tight_layout()
    plt.savefig(out_dir / "heatmap_categoria_tienda.png", dpi=150)
    plt.close()

print("\nGráficos guardados en:", out_dir)


# 7) SCORE DE EFICIENCIA y RECOMENDACIÓN
#    - Normalizamos (min-max) y combinamos métricas en un score simple.
#    - Score más alto => mejor tienda; vamos a identificar la peor (score mínimo).

def minmax_s(series):
    if series.isnull().all():
        return pd.Series(np.nan, index=series.index)
    mn, mx = series.min(), series.max()
    if mx == mn:
        return pd.Series(1.0, index=series.index)  # todos iguales -> neutro
    return (series - mn) / (mx - mn)

# Preparar columnas para scoring (llenar NaN de shipping/rating con mediana o 0)
sc = summary_df.copy()
sc["avg_shipping_filled"] = sc["avg_shipping"].fillna(sc["avg_shipping"].median() if sc["avg_shipping"].notna().any() else 0)
sc["avg_rating_filled"] = sc["avg_rating"].fillna(sc["avg_rating"].median() if sc["avg_rating"].notna().any() else 0)
sc["total_revenue_s"] = minmax_s(sc["total_revenue"])
sc["avg_order_value_s"] = minmax_s(sc["avg_order_value"])
sc["avg_rating_s"] = minmax_s(sc["avg_rating_filled"])
# En shipping, menor coste es mejor -> invertimos la escala
sc["avg_shipping_s"] = 1 - minmax_s(sc["avg_shipping_filled"])

# Pesos (ajustables)
w_revenue = 0.5
w_aov = 0.2
w_rating = 0.2
w_shipping = 0.1

sc["score"] = (w_revenue * sc["total_revenue_s"]
               + w_aov * sc["avg_order_value_s"]
               + w_rating * sc["avg_rating_s"]
               + w_shipping * sc["avg_shipping_s"])

sc = sc.sort_values("score", ascending=False)
sc[["total_revenue", "avg_order_value", "avg_shipping", "avg_rating", "score"]].to_csv(out_dir / "score_tiendas.csv")
print("\nScores calculados y guardados en:", out_dir / "score_tiendas.csv")
print(sc[["total_revenue", "avg_order_value", "avg_shipping", "avg_rating", "score"]])

# Identificar peor tienda (menor score)
worst_store = sc["score"].idxmin()
worst_row = sc.loc[worst_store]


# 8) RECOMENDACIÓN (texto)

def build_recommendation(store_name, store_row, sc_df):
    rec = []
    rec.append(f"Recomendación: vender la tienda **{store_name}**.")
    rec.append("")
    rec.append("Motivos (basados en métricas):")
    rec.append(f"- Ingresos totales: {store_row['total_revenue']:,.2f}")
    rec.append(f"- Número de pedidos (aprox): {int(store_row['n_orders'])}")
    rec.append(f"- Ticket promedio (avg_order_value): {store_row['avg_order_value']:,.2f}")
    rec.append(f"- Envío promedio: {store_row['avg_shipping']:,.2f}")
    rec.append(f"- Rating promedio: {store_row['avg_rating'] if not np.isnan(store_row['avg_rating']) else 'N/A'}")
    rec.append(f"- Score combinado (cuanto mayor mejor): {store_row['score']:.4f}")
    rec.append("")
    # comparar con la mejor tienda
    best_store = sc_df["score"].idxmax()
    best_row = sc_df.loc[best_store]
    rec.append(f"Comparación rápida: la mejor tienda es {best_store} con ingresos {best_row['total_revenue']:,.2f} y score {best_row['score']:.4f}.")
    rec.append("")
    rec.append("Interpretación práctica:")
    rec.append("- La combinación de ingresos bajos, ticket promedio reducido y/o peor rating indica que la tienda requiere inversión para recuperarse.")
    rec.append("- Vender esta tienda liberaría recursos (tiempo y dinero) que se pueden reinvertir en tiendas con mayor performance.")
    rec.append("")
    rec.append("Sugerencia adicional:")
    rec.append("- Antes de vender, revisar contratos/stock pendiente y si hay productos con potencial (top products).")
    rec.append("- Si la razón principal es el alto costo de envío, evaluar optimizaciones logísticas como cambiar proveedor de envío o ajustar política de envío gratis.")
    return "\n".join(rec)

recommendation_text = build_recommendation(worst_store, worst_row, sc)

# Guardar recomendación en archivo de texto
with open(out_dir / "recomendacion.txt", "w", encoding="utf-8") as f:
    f.write(recommendation_text)

print("\n" + "="*40)
print("RECOMENDACIÓN FINAL:")
print(recommendation_text)
print("="*40)

print("\n--- FIN del script ---")
print("Revisa la carpeta:", out_dir, "para gráficos, CSVs y la recomendación en texto.")
